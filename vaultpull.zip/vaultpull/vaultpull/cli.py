#!/usr/bin/env python3
"""VaultPull - fast multi-connection downloader with proxy support.

Usage:
    python vaultpull URL [URL ...] [-c 8] [-p http://host:port] [-o downloads]

Proxy examples:
    -p http://1.2.3.4:8080
    -p socks5://127.0.0.1:1080     (needs: pip install requests[socks])

Install once:  pip install requests
"""
import argparse
import os
import re
import sys
import threading
import time
from urllib.parse import unquote, urlparse

import requests

UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"}
lock = threading.Lock()


def resolve(url, session):
    """Turn page links of some hosts into direct file links (best effort)."""
    host = urlparse(url).netloc
    if "mediafire.com" in host and "/file/" in url:
        html = session.get(url, headers=UA, timeout=30).text
        m = re.search(r'href="(https://download[^"]+)"', html)
        if m:
            return m.group(1)
        print("MediaFire: direct link nahi mila (page badal gaya ho sakta hai).")
    if "mega.nz" in host:
        sys.exit("Mega encrypted hai. Uske liye MEGAcmd ya megatools use karo.")
    return url


def get_info(url, session):
    r = session.get(url, headers={**UA, "Range": "bytes=0-0"}, stream=True, timeout=30)
    r.raise_for_status()
    final = r.url
    cr = r.headers.get("Content-Range")
    total = int(cr.split("/")[-1]) if cr else int(r.headers.get("Content-Length", 0))
    resumable = r.status_code == 206
    cd = r.headers.get("Content-Disposition", "")
    if "filename=" in cd:
        name = cd.split("filename=")[-1].strip('"; ')
    else:
        name = os.path.basename(unquote(urlparse(final).path)) or "download"
    r.close()
    return final, total, resumable, name


def worker(url, session, path, start, end, progress, idx):
    for attempt in range(5):
        try:
            pos = start + progress[idx]
            if pos > end:
                return
            h = {**UA, "Range": f"bytes={pos}-{end}"}
            with session.get(url, headers=h, stream=True, timeout=30) as r:
                r.raise_for_status()
                with open(path, "r+b") as f:
                    f.seek(pos)
                    for chunk in r.iter_content(128 * 1024):
                        f.write(chunk)
                        progress[idx] += len(chunk)
            return
        except Exception:
            time.sleep(2)


def download(url, out_dir, conns, proxy):
    s = requests.Session()
    if proxy:
        s.proxies = {"http": proxy, "https": proxy}
    url = resolve(url, s)
    final, total, resumable, name = get_info(url, s)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name)

    if not (total and resumable):
        conns = 1  # server doesn't allow ranges: single stream
    if total:
        with open(path, "wb") as f:
            f.truncate(total)
        size = total // conns
        ranges = [(i * size, total - 1 if i == conns - 1 else (i + 1) * size - 1) for i in range(conns)]
    else:
        ranges = [(0, 10**12)]

    progress = [0] * len(ranges)
    threads = [threading.Thread(target=worker, args=(final, s, path, a, b, progress, i))
               for i, (a, b) in enumerate(ranges)]
    t0 = time.time()
    for t in threads:
        t.start()
    while any(t.is_alive() for t in threads):
        done = sum(progress)
        speed = done / max(time.time() - t0, 1) / 1e6
        pct = f"{done * 100 // total}%" if total else f"{done / 1e6:.1f} MB"
        sys.stdout.write(f"\r{name}: {pct}  {speed:.2f} MB/s  ({conns} conn)")
        sys.stdout.flush()
        time.sleep(0.5)
    print(f"\nSaved: {path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("urls", nargs="+")
    p.add_argument("-o", "--output", default="downloads")
    p.add_argument("-c", "--connections", type=int, default=8)
    p.add_argument("-p", "--proxy")
    a = p.parse_args()
    for u in a.urls:
        try:
            download(u, a.output, a.connections, a.proxy)
        except Exception as e:
            print(f"\nFailed: {u} -> {e}")


if __name__ == "__main__":
    main()
