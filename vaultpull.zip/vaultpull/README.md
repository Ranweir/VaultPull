# VaultPull

Fast multi-connection file downloader with proxy support.

- Package name: `vaultpull`
- App ID (for future Android app): `com.vaultpull.app`

## Install
```
pip install .
```

## Usage
```
vaultpull URL [URL ...] -c 16 -p http://ip:port -o downloads
# or
python -m vaultpull URL
```

## Limits
- Server-side per-IP limits, timers and captchas cannot be bypassed.
- Mega is not supported (encrypted); use MEGAcmd.
- Only download files you have the right to download. Scan APKs/executables before installing.
