import os
import re
import threading
import time
from urllib.parse import unquote, urlparse

import requests
from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"}


def out_dir():
    try:
        from android.storage import primary_external_storage_path
        d = os.path.join(primary_external_storage_path(), "Download", "VaultPull")
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, ".t"), "w").close()
        return d
    except Exception:
        pass
    try:
        from jnius import autoclass
        act = autoclass("org.kivy.android.PythonActivity").mActivity
        return act.getExternalFilesDir(None).getAbsolutePath()
    except Exception:
        return os.path.abspath("downloads")


def resolve(url, s):
    if "mediafire.com" in url and "/file/" in url:
        m = re.search(r'href="(https://download[^"]+)"', s.get(url, headers=UA, timeout=30).text)
        if m:
            return m.group(1)
    if "mega.nz" in url:
        raise Exception("Mega supported nahi hai")
    return url


def info(url, s):
    r = s.get(url, headers={**UA, "Range": "bytes=0-0"}, stream=True, timeout=30)
    r.raise_for_status()
    cr = r.headers.get("Content-Range")
    total = int(cr.split("/")[-1]) if cr else int(r.headers.get("Content-Length", 0))
    cd = r.headers.get("Content-Disposition", "")
    name = cd.split("filename=")[-1].strip('"; ') if "filename=" in cd else (
        os.path.basename(unquote(urlparse(r.url).path)) or "download")
    final, ok = r.url, r.status_code == 206
    r.close()
    return final, total, ok, name


def part(url, s, path, a, b, prog, i):
    for _ in range(5):
        try:
            pos = a + prog[i]
            if pos > b:
                return
            with s.get(url, headers={**UA, "Range": f"bytes={pos}-{b}"}, stream=True, timeout=30) as r:
                r.raise_for_status()
                with open(path, "r+b") as f:
                    f.seek(pos)
                    for c in r.iter_content(128 * 1024):
                        f.write(c)
                        prog[i] += len(c)
            return
        except Exception:
            time.sleep(2)


def download(url, conns, proxy, say):
    s = requests.Session()
    if proxy:
        s.proxies = {"http": proxy, "https": proxy}
    final, total, ok, name = info(resolve(url, s), s)
    d = out_dir()
    path = os.path.join(d, name)
    if not (total and ok):
        conns = 1
    if not total:
        raise Exception("File size pata nahi chala")
    with open(path, "wb") as f:
        f.truncate(total)
    size = total // conns
    rng = [(i * size, total - 1 if i == conns - 1 else (i + 1) * size - 1) for i in range(conns)]
    prog = [0] * conns
    ts = [threading.Thread(target=part, args=(final, s, path, a, b, prog, i)) for i, (a, b) in enumerate(rng)]
    t0 = time.time()
    for t in ts:
        t.start()
    while any(t.is_alive() for t in ts):
        done = sum(prog)
        say(f"{name}\n{done * 100 // total}%  {done / max(time.time() - t0, 1) / 1e6:.2f} MB/s")
        time.sleep(0.5)
    say(f"Done!\n{path}")


class Root(BoxLayout):
    def __init__(self, **kw):
        super().__init__(orientation="vertical", padding=16, spacing=10, **kw)
        self.add_widget(Label(text="VaultPull", font_size="28sp", size_hint_y=None, height=60))
        self.url = TextInput(hint_text="Download link", multiline=False, size_hint_y=None, height=90)
        self.proxy = TextInput(hint_text="Proxy (optional) http://ip:port", multiline=False, size_hint_y=None, height=90)
        self.conns = TextInput(text="8", hint_text="Connections", multiline=False, input_filter="int",
                               size_hint_y=None, height=90)
        self.btn = Button(text="Download", size_hint_y=None, height=110, on_release=self.start)
        self.status = Label(text="Ready", halign="center")
        for w in (self.url, self.proxy, self.conns, self.btn, self.status):
            self.add_widget(w)

    def say(self, msg):
        Clock.schedule_once(lambda dt: setattr(self.status, "text", msg))

    def start(self, *_):
        url = self.url.text.strip()
        if not url:
            return self.say("Link daalo")
        n = max(1, min(32, int(self.conns.text or 8)))
        threading.Thread(target=self.run, args=(url, n, self.proxy.text.strip() or None), daemon=True).start()

    def run(self, url, n, proxy):
        try:
            download(url, n, proxy, self.say)
        except Exception as e:
            self.say(f"Failed: {e}")


class VaultPull(App):
    def build(self):
        return Root()

    def on_start(self):
        try:
            from android.permissions import Permission, request_permissions
            request_permissions([Permission.WRITE_EXTERNAL_STORAGE, Permission.READ_EXTERNAL_STORAGE])
        except Exception:
            pass


if __name__ == "__main__":
    VaultPull().run()
