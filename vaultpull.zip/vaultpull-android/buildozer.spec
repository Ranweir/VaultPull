[app]
title = VaultPull
package.name = app
package.domain = com.vaultpull
source.dir = .
source.include_exts = py
version = 1.0.0
requirements = python3,kivy,requests,urllib3,certifi,idna,charset-normalizer,pysocks
orientation = portrait
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.api = 33
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 0
