# VaultPull (native Android)

Multi-connection file downloader. Package: `com.vaultpull.app`

- Parallel segments, proxy (HTTP / SOCKS5), MediaFire page-link resolver
- Saves to Downloads/VaultPull (Android 10+)
- Share a link to VaultPull from any app to prefill it

Build locally: `gradle assembleDebug`
