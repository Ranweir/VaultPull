package com.vaultpull.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var urlBox: EditText
    private lateinit var proxyBox: EditText
    private lateinit var connBox: EditText
    private lateinit var startBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private var engine: DownloadEngine? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun field(hintText: String, type: Int) = EditText(this).apply {
        hint = hintText
        inputType = type
        setSingleLine(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        val title = TextView(this).apply {
            text = "VaultPull"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val uriType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlBox = field("Download link", uriType)
        proxyBox = field("Proxy (optional): http://ip:port ya socks5://ip:port", uriType)
        connBox = field("Connections (1-32)", InputType.TYPE_CLASS_NUMBER).apply { setText("8") }
        startBtn = Button(this).apply {
            text = "Download"
            setOnClickListener { start() }
        }
        cancelBtn = Button(this).apply {
            text = "Cancel"
            isEnabled = false
            setOnClickListener { engine?.cancelled = true }
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        status = TextView(this).apply {
            text = "Ready"
            setPadding(0, dp(16), 0, 0)
        }

        for (v in listOf(title, urlBox, proxyBox, connBox, startBtn, cancelBtn, bar, status)) {
            root.addView(
                v,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        setContentView(root)

        intent?.getStringExtra(Intent.EXTRA_TEXT)?.let { urlBox.setText(it.trim()) }
    }

    private fun show(msg: String, pct: Int) {
        status.text = msg
        if (pct < 0) {
            bar.isIndeterminate = true
        } else {
            bar.isIndeterminate = false
            bar.progress = pct
        }
    }

    private fun start() {
        val link = urlBox.text.toString().trim()
        if (link.isEmpty()) {
            status.text = "Link daalo"
            return
        }
        val n = connBox.text.toString().toIntOrNull() ?: 8
        val proxy = proxyBox.text.toString().trim()
        val eng = DownloadEngine(applicationContext)
        engine = eng
        startBtn.isEnabled = false
        cancelBtn.isEnabled = true
        Thread {
            try {
                val name = eng.download(link, n, proxy) { msg, pct -> runOnUiThread { show(msg, pct) } }
                runOnUiThread { show("Done!\nDownload/VaultPull/$name", 100) }
            } catch (ex: Exception) {
                runOnUiThread { show("Failed: ${ex.message}", 0) }
            } finally {
                runOnUiThread {
                    startBtn.isEnabled = true
                    cancelBtn.isEnabled = false
                }
            }
        }.start()
    }
}
