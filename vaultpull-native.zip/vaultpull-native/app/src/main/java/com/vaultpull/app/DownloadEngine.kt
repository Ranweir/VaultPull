package com.vaultpull.app

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicLongArray
import kotlin.math.max

class DownloadEngine(private val ctx: Context) {

    @Volatile
    var cancelled = false

    private class Info(val url: String, val total: Long, val ranges: Boolean, val name: String)

    private val ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun parseProxy(s: String?): Proxy? {
        if (s.isNullOrBlank()) return null
        val u = URI(if (s.contains("://")) s else "http://$s")
        require(u.host != null && u.port > 0) { "Proxy ka format: http://ip:port" }
        val type = if (u.scheme.startsWith("socks")) Proxy.Type.SOCKS else Proxy.Type.HTTP
        return Proxy(type, InetSocketAddress.createUnresolved(u.host, u.port))
    }

    private fun connect(url: String, proxy: Proxy?, range: String?): HttpURLConnection {
        val u = URL(url)
        val c = (if (proxy != null) u.openConnection(proxy) else u.openConnection()) as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Encoding", "identity")
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    private fun openFollow(start: String, proxy: Proxy?, range: String?): Pair<HttpURLConnection, String> {
        var cur = start
        for (i in 0 until 10) {
            val c = connect(cur, proxy, range)
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location") ?: throw Exception("Redirect adhura")
                c.disconnect()
                cur = URL(URL(cur), loc).toString()
                continue
            }
            if (code >= 400) {
                c.disconnect()
                throw Exception("Server error $code")
            }
            return Pair(c, cur)
        }
        throw Exception("Bahut zyada redirects")
    }

    private fun resolve(url: String, proxy: Proxy?): String {
        val host = URL(url).host
        if (host.contains("mega.nz") || host.contains("mega.io")) {
            throw Exception("Mega supported nahi hai (encrypted)")
        }
        if (host.contains("mediafire.com") && url.contains("/file")) {
            val (c, _) = openFollow(url, proxy, null)
            val html = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val m = Regex("href=\"(https://download[^\"]+)\"").find(html)
                ?: throw Exception("MediaFire direct link nahi mila")
            return m.groupValues[1]
        }
        return url
    }

    private fun probe(url: String, proxy: Proxy?): Info {
        val (c, finalUrl) = openFollow(url, proxy, "bytes=0-0")
        val code = c.responseCode
        val cr = c.getHeaderField("Content-Range")
        val total = if (code == 206 && cr != null) {
            cr.substringAfterLast('/').toLongOrNull() ?: -1L
        } else {
            c.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
        }
        val cd = c.getHeaderField("Content-Disposition") ?: ""
        c.disconnect()
        val fromCd = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
            .find(cd)?.groupValues?.get(1)
        val raw = fromCd ?: URL(finalUrl).path.substringAfterLast('/')
        val decoded = try { URLDecoder.decode(raw, "UTF-8") } catch (e: Exception) { raw }
        val name = decoded.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "download" }
        return Info(finalUrl, total, code == 206 && total > 0, name)
    }

    /** Downloads into Downloads/VaultPull. Returns saved file name. */
    fun download(rawUrl: String, connsIn: Int, proxyStr: String?, onStatus: (String, Int) -> Unit): String {
        cancelled = false
        val proxy = parseProxy(proxyStr)
        onStatus("Link check ho raha hai...", -1)
        val info = probe(resolve(rawUrl, proxy), proxy)
        val conns = if (info.ranges) connsIn.coerceIn(1, 32) else 1

        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, info.name)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VaultPull")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("File nahi ban payi")
        var ok = false
        try {
            val pfd = resolver.openFileDescriptor(uri, "rw") ?: throw Exception("File open nahi hui")
            try {
                val ch = FileOutputStream(pfd.fileDescriptor).channel
                if (info.total > 0) ch.write(ByteBuffer.wrap(byteArrayOf(0)), info.total - 1)
                runParts(info, conns, proxy, ch, onStatus)
            } finally {
                pfd.close()
            }
            ok = true
        } finally {
            if (ok) {
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } else {
                resolver.delete(uri, null, null)
            }
        }
        return info.name
    }

    private fun runParts(info: Info, conns: Int, proxy: Proxy?, ch: FileChannel, onStatus: (String, Int) -> Unit) {
        val total = info.total
        val size = if (total > 0) total / conns else 0L
        val starts = LongArray(conns) { it * size }
        val ends = LongArray(conns) {
            if (total <= 0) Long.MAX_VALUE else if (it == conns - 1) total - 1 else (it + 1) * size - 1
        }
        val prog = AtomicLongArray(conns)
        val pool = Executors.newFixedThreadPool(conns)
        val futures: List<Future<Boolean>> = (0 until conns).map { i ->
            pool.submit(Callable<Boolean> { part(info, proxy, ch, starts[i], ends[i], prog, i) })
        }
        val t0 = System.currentTimeMillis()
        try {
            while (futures.any { !it.isDone }) {
                if (cancelled) throw Exception("Cancel kiya")
                var done = 0L
                for (i in 0 until conns) done += prog.get(i)
                val sec = max(1.0, (System.currentTimeMillis() - t0) / 1000.0)
                val speed = String.format("%.2f MB/s", done / sec / 1e6)
                val sz = if (total > 0) {
                    String.format("%.1f / %.1f MB", done / 1e6, total / 1e6)
                } else {
                    String.format("%.1f MB", done / 1e6)
                }
                val pct = if (total > 0) (done * 100 / total).toInt() else -1
                onStatus(info.name + "\n" + sz + "  |  " + speed + "  |  " + conns + " conn", pct)
                Thread.sleep(400)
            }
        } finally {
            pool.shutdownNow()
        }
        if (futures.any { !it.get() }) throw Exception("Download adhura reh gaya (network/server)")
    }

    private fun part(
        info: Info, proxy: Proxy?, ch: FileChannel,
        start: Long, end: Long, prog: AtomicLongArray, i: Int
    ): Boolean {
        val buf = ByteArray(128 * 1024)
        for (attempt in 0 until 5) {
            if (cancelled) return false
            try {
                if (!info.ranges) prog.set(i, 0)
                val pos0 = start + prog.get(i)
                if (info.ranges && pos0 > end) return true
                val range = if (info.ranges) "bytes=$pos0-$end" else null
                val (c, _) = openFollow(info.url, proxy, range)
                if (info.ranges && c.responseCode != 206) throw Exception("Range support nahi")
                c.inputStream.use { ins ->
                    while (true) {
                        if (cancelled) return false
                        val n = ins.read(buf)
                        if (n < 0) break
                        val bb = ByteBuffer.wrap(buf, 0, n)
                        var p = start + prog.get(i)
                        while (bb.hasRemaining()) p += ch.write(bb, p)
                        prog.addAndGet(i, n.toLong())
                    }
                }
                c.disconnect()
                if (!info.ranges || start + prog.get(i) > end) return true
            } catch (e: Exception) {
                if (cancelled) return false
                Thread.sleep(1500)
            }
        }
        return false
    }
}
